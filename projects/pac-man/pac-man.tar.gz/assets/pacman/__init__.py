"""Pac-Man game package."""
