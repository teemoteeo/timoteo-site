"""Game rules: levels, score, lives, timer, ghosts, cheats. No drawing.

Timings and speed ratios follow the arcade game as documented in
Jamey Pittman's "Pac-Man Dossier".
"""

import random
from functools import partial

from pacman.config import HEIGHT_RANGE, WIDTH_RANGE, Config
from pacman.entities import Ghost, Player
from pacman.maze import Level, Tile, generate_grid

READY_TIME = 2.0
DEATH_TIME = 1.6
CLEAR_TIME = 1.6
POPUP_TIME = 1.0
HIT_DISTANCE = 0.6
EYES_SPEED = 1.8               # x player speed

# Percent of full speed: (Pac-Man, Pac-Man energized, ghost,
# frightened ghost) for level 1, levels 2-4 and levels 5+.
SPEEDS = ((80, 90, 75, 50), (90, 95, 85, 55), (100, 100, 95, 60))
# Scatter, chase, scatter, chase... seconds; then chase forever.
WAVES = ((7, 20, 7, 20, 5, 20, 5), (7, 20, 7, 20, 5, 1033, 0),
         (5, 20, 5, 20, 5, 1037, 0))
# Frightened seconds per level on the arcade (level 1 = 6 s).
FRIGHT = (6, 5, 4, 3, 2, 5, 2, 2, 1, 5, 2, 1, 1, 3, 1, 1, 0, 1)
# Bonus fruit per level (the last one repeats), shown at 70/170 dots.
FRUITS = (("cherry", 100), ("strawberry", 300), ("orange", 500),
          ("orange", 500), ("apple", 700), ("apple", 700),
          ("melon", 1000), ("melon", 1000), ("galaxian", 2000),
          ("galaxian", 2000), ("bell", 3000), ("bell", 3000),
          ("key", 5000))
FRUIT_DOTS = (70, 170)
FRUIT_TIME = 9.5

Popup = tuple[float, float, str, float]


class Game:
    """One run, from level 1 to victory or game over.

    Attributes:
        state: "playing", "won" or "lost".
        double: Double mode: maze twice as big, 8 ghosts, double time.
        score: Never decreases.
        lives: Remaining lives.
        level_index: 0-based current level.
        time_left: Seconds left for the level.
        ready: Seconds of "READY!" freeze left.
        dying: Seconds of death animation left (0 = alive).
        clearing: Seconds of level-cleared flash left.
        wave: Seconds of play since the level (or life) started.
        fruit: Seconds the bonus fruit stays (0 = none).
        regrow: Eaten pellets growing back: tile -> (super?, seconds).
        popups: Floating texts ``(x, y, text, seconds_left)``.
        cheat: Cheat mode on; enables the flags below and cheat keys.
        invincible: Ghosts cannot kill the player.
        frozen: Ghosts do not move.
        fast: Player moves twice as fast.
    """

    def __init__(self, cfg: Config, rng: random.Random | None = None,
                 double: bool = False) -> None:
        """Start a new run on level 1.

        Raises:
            MazeError: If the first maze cannot be generated.
        """
        self.cfg = cfg
        self.rng = rng or random.Random()
        self.double = double
        self.state = "playing"
        self.score = 0
        self.lives = cfg.lives
        self.bonus_life_given = False
        self.cheat = cfg.cheat_mode
        self.invincible = self.frozen = self.fast = False
        self.popups: list[Popup] = []
        self.start_level(0)

    # ---- level lifecycle ---------------------------------------------

    def start_level(self, index: int) -> None:
        """Generate level ``index`` (fixed seed for the first one).

        Raises:
            MazeError: If the maze package fails.
        """
        spec = self.cfg.levels[index]
        w, h = spec.width, spec.height
        if self.double:
            w, h = min(2 * w, WIDTH_RANGE[1]), min(2 * h, HEIGHT_RANGE[1])
        seed = self.cfg.seed if index == 0 else self.rng.randrange(2**31)
        self.level = Level(generate_grid(
            self.cfg.maze_package, self.cfg.maze_factory, w, h, seed))
        self.level_index = index
        self.total = len(self.level.uneaten)
        self.player = Player(self.level.start)
        homes = self.level.ghost_homes(8 if self.double else 4)
        self.ghosts = [Ghost(i, home) for i, home in enumerate(homes)]
        self.time_left = self.max_time()
        self.dying = self.clearing = self.fruit = 0.0
        self.fruits_shown = 0
        self.regrow: dict[Tile, tuple[bool, float]] = {}
        self._respawn()

    def max_time(self) -> float:
        """Seconds allowed per level (doubled in Double mode)."""
        return float(self.cfg.level_max_time * (2 if self.double else 1))

    def complete_level(self) -> None:
        """Go to the next level, or win after the last one."""
        if self.level_index + 1 >= len(self.cfg.levels):
            self.state = "won"
        else:
            self.start_level(self.level_index + 1)

    # ---- arcade tables -----------------------------------------------

    def _tier(self) -> int:
        """Speed/wave table row: level 1, levels 2-4, levels 5+."""
        if self.level_index == 0:
            return 0
        return 1 if self.level_index < 4 else 2

    def scatter(self) -> bool:
        """Tell whether ghosts are in a scatter wave (going home)."""
        t = self.wave
        for i, length in enumerate(WAVES[self._tier()]):
            if t < length:
                return i % 2 == 0
            t -= length
        return False

    def fright_time(self) -> float:
        """Frightened duration on this level, scaled by the config."""
        base = FRIGHT[min(self.level_index, len(FRIGHT) - 1)]
        return self.cfg.frightened_time * base / FRIGHT[0]

    def fruit_kind(self) -> tuple[str, int]:
        """(name, points) of this level's bonus fruit."""
        return FRUITS[min(self.level_index, len(FRUITS) - 1)]

    def elroy(self) -> int:
        """Cruise Elroy stage: Blinky speeds up when few dots remain."""
        left = len(self.level.uneaten)
        limit = max(10, self.total // 12)
        if left <= limit // 2:
            return 2
        return 1 if left <= limit else 0

    # ---- update ------------------------------------------------------

    def steer(self, d: Tile) -> None:
        """Forward a direction key to the player."""
        self.player.steer(d)

    def update(self, dt: float) -> None:
        """Advance the simulation by ``dt`` seconds.

        Raises:
            MazeError: If the next level's maze cannot be generated.
        """
        if self.state != "playing":
            return
        self.popups = [(x, y, s, t - dt) for x, y, s, t in self.popups
                       if t > dt]
        if self.dying > 0:
            self.dying -= dt
            if self.dying <= 0:
                self._after_death()
            return
        if self.clearing > 0:
            self.clearing -= dt
            if self.clearing <= 0:
                self.complete_level()
            return
        if self.ready > 0:
            self.ready -= dt
            return
        self.time_left -= dt
        if self.time_left <= 0:
            self.time_left = 0.0
            self.dying = DEATH_TIME
            return
        was_scatter = self.scatter()
        self.wave += dt
        if self.scatter() != was_scatter:
            for g in self.ghosts:             # arcade: reverse on switch
                if not g.eaten and g.frightened <= 0:
                    g.reverse()
        self._regrow(dt)
        self._move_player(dt)
        if not self.level.uneaten:
            self.clearing = CLEAR_TIME
            return
        self._move_ghosts(dt)
        self._collide()

    def _move_player(self, dt: float) -> None:
        """Move Pac-Man (faster while ghosts are frightened)."""
        pac, pac_fast, _, _ = SPEEDS[self._tier()]
        energized = any(g.frightened > 0 for g in self.ghosts)
        pct = pac_fast if energized else pac
        speed = self.cfg.player_speed * pct / SPEEDS[0][0]
        self.player.advance(speed * dt * (2 if self.fast else 1),
                            lambda: self.player.choose(self.level), self._eat)
        if self.fruit > 0:
            self.fruit -= dt
            if self.player.tile == self.level.start:
                points = self.fruit_kind()[1]
                self._add_score(points)
                self._popup(self.level.start, str(points))
                self.fruit = 0.0

    def _move_ghosts(self, dt: float) -> None:
        """Release, move and respawn the ghosts."""
        _, _, ghost, scared = SPEEDS[self._tier()]
        base = self.cfg.ghost_speed / SPEEDS[0][2] * dt
        scatter, elroy, blinky = self.scatter(), self.elroy(), self.ghosts[0]
        for g in self.ghosts:
            angry = g.kind == 0 and elroy > 0
            choose = partial(g.choose, self.level, self.player, self.rng,
                             scatter and not angry, blinky)
            if g.eaten:
                g.dead -= dt
                if g.tile == g.home and g.nxt is None:
                    if g.dead <= 0:
                        g.reset(g.home)
                        g.wait = 0.0
                    continue
                g.advance(self.cfg.player_speed * EYES_SPEED * dt, choose,
                          lambda _t: None)
                continue
            g.frightened = max(0.0, g.frightened - dt)
            if g.wait > 0:
                g.wait -= dt
            elif not self.frozen:
                pct = scared if g.frightened > 0 else \
                    ghost + (5 * elroy if angry else 0)
                g.advance(base * pct, choose, lambda _t: None)

    def _regrow(self, dt: float) -> None:
        """Grow eaten pellets back once their delay is over."""
        for tile, (big, left) in list(self.regrow.items()):
            if left > dt:
                self.regrow[tile] = (big, left - dt)
            elif tile != self.player.tile:
                del self.regrow[tile]
                self.level.pellets[tile] = big

    # ---- events ------------------------------------------------------

    def _eat(self, tile: Tile) -> None:
        """Eat the pellet on ``tile``, if any."""
        big = self.level.pellets.pop(tile, None)
        if big is None:
            return
        self.level.uneaten.discard(tile)
        if self.cfg.food_respawn_time > 0:
            self.regrow[tile] = (big, self.cfg.food_respawn_time)
        if big:
            self._add_score(self.cfg.points_per_super_pacgum)
            self.frighten()
        else:
            self._add_score(self.cfg.points_per_pacgum)
        eaten = self.total - len(self.level.uneaten)
        if (self.fruits_shown < len(FRUIT_DOTS)
                and eaten >= FRUIT_DOTS[self.fruits_shown]):
            self.fruits_shown += 1
            self.fruit = FRUIT_TIME

    def frighten(self, seconds: float | None = None) -> None:
        """Make every living ghost edible and turn around.

        Args:
            seconds: Duration; the level's frightened time by default.
        """
        for g in self.ghosts:
            if not g.eaten:
                g.reverse()
                g.frightened = self.fright_time() if seconds is None \
                    else seconds

    def _add_score(self, points: int) -> None:
        """Add points; award the one-time extra life when reached."""
        self.score += points
        bonus = self.cfg.extra_life_score
        if bonus and not self.bonus_life_given and self.score >= bonus:
            self.bonus_life_given = True
            self.lives += 1
            self._popup(self.player.tile, "1UP")

    def _popup(self, tile: Tile, text: str) -> None:
        """Show a floating text over ``tile``."""
        self.popups.append((float(tile[0]), float(tile[1]), text,
                            POPUP_TIME))

    def _collide(self) -> None:
        """Resolve player/ghost contacts."""
        px, py = self.player.pos()
        for g in self.ghosts:
            gx, gy = g.pos()
            if g.eaten or abs(gx - px) + abs(gy - py) >= HIT_DISTANCE:
                continue
            if g.frightened > 0:
                self._add_score(self.cfg.points_per_ghost)
                self.popups.append((gx, gy, str(self.cfg.points_per_ghost),
                                    POPUP_TIME))
                g.eaten, g.frightened = True, 0.0
                g.dead = self.cfg.ghost_respawn_time
            elif not self.invincible:
                self.dying = DEATH_TIME
                return

    def _after_death(self) -> None:
        """Lose a life; respawn everyone or end the game."""
        self.lives -= 1
        if self.lives <= 0:
            self.lives = 0
            self.state = "lost"
            return
        if self.time_left <= 0:
            self.time_left = self.max_time()
        self._respawn()

    def _respawn(self) -> None:
        """Put everyone back on their spawn and show READY!."""
        self.player.reset(self.level.start)
        for g in self.ghosts:
            g.reset(g.home)
        self.wave = 0.0
        self.ready = READY_TIME
        self.fruit = 0.0

    # ---- cheats ------------------------------------------------------

    def toggle_cheat(self) -> None:
        """Switch cheat mode; switching it off clears every cheat flag."""
        self.cheat = not self.cheat
        if not self.cheat:
            self.invincible = self.frozen = self.fast = False

    def cheat_key(self, key: str) -> None:
        """Apply a cheat key ('1'-'7'); ignored unless cheat mode is on."""
        if not self.cheat:
            return
        if key == "1":
            self.invincible = not self.invincible
        elif key == "2":
            self.frozen = not self.frozen
        elif key == "3":
            self.fast = not self.fast
        elif key == "4":
            self.lives += 1
        elif key == "5":
            self.time_left += 30
        elif key == "6":
            self.frighten(self.cfg.frightened_time)
        elif key == "7":
            self.complete_level()
