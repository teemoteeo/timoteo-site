"""Moving entities: Pac-Man and the ghosts, on a tile grid."""

import random
from typing import Callable

from pacman.maze import DIRS, Level, Tile, add

STOP: Tile = (0, 0)


def opposite(d: Tile) -> Tile:
    """Return the reverse direction."""
    return (-d[0], -d[1])


class Mover:
    """Something that slides from tile to tile.

    Attributes:
        tile: Tile it is leaving (or standing on).
        nxt: Tile it is heading to, None when standing still.
        t: Progress from ``tile`` to ``nxt``, in [0, 1).
        dir: Current (or last) direction.
    """

    def __init__(self, tile: Tile) -> None:
        """Place the mover on ``tile``, standing still."""
        self.reset(tile)

    def reset(self, tile: Tile) -> None:
        """Teleport to ``tile`` and stop."""
        self.tile: Tile = tile
        self.nxt: Tile | None = None
        self.t = 0.0
        self.dir = STOP

    def pos(self) -> tuple[float, float]:
        """Return the exact (fractional) tile position."""
        if self.nxt is None:
            return (float(self.tile[0]), float(self.tile[1]))
        return (self.tile[0] + (self.nxt[0] - self.tile[0]) * self.t,
                self.tile[1] + (self.nxt[1] - self.tile[1]) * self.t)

    def reverse(self) -> None:
        """Turn around mid-corridor."""
        if self.nxt is not None:
            self.tile, self.nxt = self.nxt, self.tile
            self.t = 1.0 - self.t
        self.dir = opposite(self.dir)

    def advance(self, dist: float, choose: Callable[[], Tile | None],
                arrive: Callable[[Tile], None]) -> None:
        """Move ``dist`` tiles, asking ``choose`` at every crossing.

        Args:
            dist: Distance to travel this frame, in tiles.
            choose: Returns the next direction, or None to stop.
            arrive: Called with each tile reached.
        """
        while dist > 0:
            if self.nxt is None:
                d = choose()
                if d is None:
                    return
                self.dir, self.nxt = d, add(self.tile, d)
            remaining = 1.0 - self.t
            if dist < remaining:
                self.t += dist
                return
            dist -= remaining
            self.tile, self.nxt, self.t = self.nxt, None, 0.0
            arrive(self.tile)


class Player(Mover):
    """Pac-Man: goes where the last pressed key says, when possible."""

    def reset(self, tile: Tile) -> None:
        """Respawn on ``tile`` with no buffered input."""
        super().reset(tile)
        self.want = STOP

    def steer(self, d: Tile) -> None:
        """Buffer a direction; reversing is immediate."""
        self.want = d
        if self.nxt is not None and d == opposite(self.dir):
            self.reverse()

    def choose(self, level: Level) -> Tile | None:
        """Take the wanted turn if open, else keep going, else stop."""
        for d in (self.want, self.dir):
            if d != STOP and level.is_open(add(self.tile, d)):
                return d
        return None


class Ghost(Mover):
    """A ghost. Personality = index % 4, as in the arcade:
    0 Blinky chases, 1 Pinky ambushes, 2 Inky flanks with Blinky,
    3 Clyde chases but retreats when close.

    Attributes:
        index: Ghost number (0-7 in Double mode).
        kind: Personality, 0-3.
        home: Spawn tile, also its scatter target.
        wait: Seconds before it is released.
        frightened: Seconds left being edible.
        dead: Seconds left before respawning.
        eaten: True from being eaten until it respawns (eyes only).
    """

    def __init__(self, index: int, home: Tile) -> None:
        """Create ghost ``index`` on its spawn tile."""
        self.index = index
        self.kind = index % 4
        self.home = home
        super().__init__(home)

    def reset(self, tile: Tile) -> None:
        """Respawn alive and dangerous on ``tile``."""
        super().reset(tile)
        self.wait = 1.5 * self.index
        self.frightened = 0.0
        self.dead = 0.0
        self.eaten = False

    def target(self, level: Level, player: Player,
               blinky: "Ghost") -> Tile:
        """Chase target, per the Pac-Man Dossier.

        Blinky: Pac-Man's tile. Pinky: 4 tiles ahead of him. Inky: the
        point 2 tiles ahead of Pac-Man, mirrored around Blinky (the
        vector Blinky -> that point, doubled). Clyde: Pac-Man while more
        than 8 tiles away, else his own corner.
        """
        p, d = player.tile, player.dir
        if self.kind == 1:
            goal = (p[0] + 4 * d[0], p[1] + 4 * d[1])
        elif self.kind == 2:
            ax, ay = p[0] + 2 * d[0], p[1] + 2 * d[1]
            goal = (2 * ax - blinky.tile[0], 2 * ay - blinky.tile[1])
        elif self.kind == 3:
            dx, dy = self.tile[0] - p[0], self.tile[1] - p[1]
            goal = p if dx * dx + dy * dy > 64 else self.home
        else:
            goal = p
        return goal if goal in level.region else level.closest(*goal)

    def choose(self, level: Level, player: Player, rng: random.Random,
               scatter: bool, blinky: "Ghost") -> Tile | None:
        """Choose a direction at a crossing (no U-turn unless dead end).

        Eyes go home, frightened ghosts take the step farthest from the
        player, others walk the shortest path (BFS) to their target:
        their corner in scatter waves, their personality otherwise.
        """
        if self.eaten and self.tile == self.home:
            return None
        options = [d for d in DIRS if level.is_open(add(self.tile, d))]
        if (not self.eaten and len(options) > 1
                and opposite(self.dir) in options):
            options.remove(opposite(self.dir))
        if not options:
            return None
        if self.frightened > 0 and not self.eaten:
            far = level.distances(player.tile)
            return max(options, key=lambda d: (far.get(add(self.tile, d), 0),
                                               rng.random()))
        if self.eaten or scatter:
            goal = self.home
        else:
            goal = self.target(level, player, blinky)
        near = level.distances(goal)
        return min(options, key=lambda d: (near.get(add(self.tile, d), 10**6),
                                           rng.random()))
