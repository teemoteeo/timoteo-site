"""Screens (menu, game, pause, name entry...) and the main loop.

Visual language: arcade identity in the game itself (pixel font, neon
maze), Apple Human Interface Guidelines for everything around it: dark
translucent rounded panels, pill-shaped selection, keycaps, SF Pro
Rounded text, an 8-point spacing grid and short fade transitions.
"""

import logging
import time
from functools import partial
from typing import Callable

from pacman import sprites
from pacman.config import Config
from pacman.entities import Ghost
from pacman.game import DEATH_TIME, Game
from pacman.gfx import QUIT, Image, Window, screen_size
from pacman.highscores import NAME_MAX, Highscores, valid_char, valid_name
from pacman.maze import DOWN, LEFT, RIGHT, UP, Level, MazeError, Tile
from pacman.sprites import RGB, RGBA

log = logging.getLogger("pacman")

FPS = 60
WARM_BUDGET = 0.008            # seconds per frame spent pre-building sprites

# Apple dark-mode system colours and label hierarchy.
LABEL: RGB = (245, 245, 250)
LABEL2: RGB = (160, 165, 190)
LABEL3: RGB = (105, 110, 135)
YELLOW: RGB = (255, 214, 10)
RED: RGB = (255, 69, 58)
GREEN: RGB = (48, 209, 88)
TEAL: RGB = (100, 210, 255)
PINK: RGB = (255, 120, 190)
SHADOW: RGB = (0, 0, 0)
GLASS: RGBA = (24, 26, 52, 248)
GLASS_EDGE: RGBA = (255, 255, 255, 34)
MEDALS: tuple[RGB, ...] = ((255, 214, 10), (205, 210, 220), (205, 127, 50))

MOVE_KEYS: dict[str, Tile] = {
    "up": UP, "w": UP, "down": DOWN, "s": DOWN,
    "left": LEFT, "a": LEFT, "right": RIGHT, "d": RIGHT,
}
OK_KEYS = ("return", "enter", "space")
PAUSE_MENU = ("Resume", "Main Menu")
CHEATS = (("1", "Invincible"), ("2", "Freeze ghosts"), ("3", "Speed x2"),
          ("4", "Extra life"), ("5", "+30 seconds"), ("6", "Power pellet"),
          ("7", "Skip level"))


class App:
    """State machine: menu, highscores, instructions, play, pause,
    name entry, message. One state at a time, one loop."""

    def __init__(self, cfg: Config) -> None:
        """Load highscores and open a window sized to the screen."""
        self.cfg = cfg
        self.scores = Highscores(cfg.highscore_filename)
        self.scores.load()
        dw, dh = screen_size()
        hp = max(600, min(dh - 90, 1100))
        wp = max(800, min(dw - 60, int(hp * 1.5)))
        self.win = Window(wp, hp, "Pac-Man")
        self.w, self.h = self.win.width, self.win.height
        self.k = self.h / 900
        self.dim = Image(self.w, self.h)
        self.dim.rect(0, 0, self.w, self.h, (0, 0, 0, 170))
        self.veil = Image(self.w, self.h)
        self.state = "menu"
        self.cursor = 0
        self.pill = -1.0
        self.fade = 1.0
        self.double = cfg.double_mode
        self.game: Game | None = None
        self.name = ""
        self.message = ""
        self.clock = 0.0
        self.dt = 0.0
        self.running = True
        self._mazes: dict[tuple[int, bool], Image] = {}
        self._maze_level: Level | None = None
        self._warm: list[Callable[[], object]] = []

    def run(self) -> None:
        """Main loop at ~60 frames per second, until Quit."""
        last = time.monotonic()
        try:
            while self.running:
                now = time.monotonic()
                self.dt = min(now - last, 0.05)
                last = now
                self.clock += self.dt
                for key, char in self.win.events():
                    self.on_key(key, char)
                self.update(self.dt)
                self.draw()
                self.win.present()
                self._prewarm(now)
                time.sleep(max(0.0, 1 / FPS - (time.monotonic() - now)))
        finally:
            self.win.destroy()

    # ---- input -------------------------------------------------------

    def go(self, state: str) -> None:
        """Switch screen with a short fade-in."""
        self.state, self.cursor, self.pill, self.fade = state, 0, -1.0, 1.0

    def menu_items(self) -> tuple[str, ...]:
        """Main menu labels (the mode item shows the current mode)."""
        mode = "Double" if self.double else "Classic"
        return ("Start Game", f"Mode:  ‹ {mode} ›", "Highscores",
                "Instructions", "Quit")

    def on_key(self, key: str, char: str) -> None:
        """Route one key press to the current screen."""
        if key == QUIT:
            self.running = False
        elif self.state == "menu":
            self._main_menu_key(key)
        elif self.state in ("scores", "help", "message"):
            if key in OK_KEYS or key in ("escape", "backspace"):
                self.go("menu")
        elif self.state == "play" and self.game is not None:
            if key in MOVE_KEYS:
                self.game.steer(MOVE_KEYS[key])
            elif key in ("p", "escape"):
                self.state, self.cursor, self.pill = "pause", 0, -1.0
            elif key == "c":
                self.game.toggle_cheat()
            else:
                self._guard(lambda g: g.cheat_key(key))
        elif self.state == "pause":
            choice = self._menu_key(key, len(PAUSE_MENU))
            if choice == 0 or key in ("p", "escape"):
                self.state = "play"
            elif choice == 1:
                self.game = None
                self.go("menu")
        elif self.state == "name":
            self._name_key(key, char)

    def _main_menu_key(self, key: str) -> None:
        """Main menu: Enter activates, Left/Right change the mode."""
        if self.cursor == 1 and key in ("left", "right", "a", "d"):
            self.double = not self.double
            return
        choice = self._menu_key(key, len(self.menu_items()))
        if choice == 0:
            self.start_game()
        elif choice == 1:
            self.double = not self.double
        elif choice == 2:
            self.go("scores")
        elif choice == 3:
            self.go("help")
        elif choice == 4 or key == "escape":
            self.running = False

    def _menu_key(self, key: str, count: int) -> int | None:
        """Move the cursor; return the index chosen with Enter/Space."""
        if key in ("up", "w"):
            self.cursor = (self.cursor - 1) % count
        elif key in ("down", "s"):
            self.cursor = (self.cursor + 1) % count
        elif key in OK_KEYS:
            return self.cursor
        return None

    def _name_key(self, key: str, char: str) -> None:
        """Edit the player name; Enter saves, Esc skips."""
        if key == "backspace":
            self.name = self.name[:-1]
        elif key in ("return", "enter") and self.game is not None:
            if valid_name(self.name):
                self.scores.add(self.name, self.game.score)
                self.scores.save()
                self.game = None
                self.go("menu")
        elif key == "escape":
            self.game = None
            self.go("menu")
        elif valid_char(char) and len(self.name) < NAME_MAX:
            self.name += char.upper()

    # ---- logic -------------------------------------------------------

    def start_game(self) -> None:
        """Create a new Game, or show why the maze failed."""
        try:
            self.game = Game(self.cfg, double=self.double)
        except MazeError as e:
            self._fail(e)
            return
        self.go("play")

    def _guard(self, action: Callable[[Game], None]) -> None:
        """Run a game action that may generate a maze."""
        if self.game is None:
            return
        try:
            action(self.game)
        except MazeError as e:
            self._fail(e)

    def _fail(self, e: MazeError) -> None:
        """Show a maze error and drop the current game."""
        log.error("%s", e)
        self.message, self.game = str(e), None
        self.go("message")

    def update(self, dt: float) -> None:
        """Advance the game while playing; detect its end."""
        self.fade = max(0.0, self.fade - dt * 4)
        if self.state != "play" or self.game is None:
            return
        self._guard(lambda g: g.update(dt))
        if self.game is not None and self.game.state != "playing":
            self.state, self.name = "name", ""

    def _prewarm(self, frame_start: float) -> None:
        """Build queued sprites while the frame budget allows."""
        while self._warm and time.monotonic() - frame_start < WARM_BUDGET:
            self._warm.pop()()

    # ---- drawing helpers ---------------------------------------------

    def fs(self, n: int) -> int:
        """Scaled arcade font size, a multiple of 8 (crisp pixels)."""
        return max(8, round(n * self.k / 8) * 8)

    def u(self, n: float) -> int:
        """Scaled length in pixels (8-point grid at 900 px high)."""
        return round(n * self.k)

    def text(self, x: int, y: int, color: RGB, s: str, size: int,
             center: bool = True) -> None:
        """Arcade text with a drop shadow; ``size`` is unscaled."""
        px = self.fs(size)
        off = max(2, px // 8)
        self.win.string_put(x + off, y + off, SHADOW, s, px, center)
        self.win.string_put(x, y, color, s, px, center)

    def ui(self, x: int, y: int, color: RGB, s: str, size: int,
           center: bool = True) -> None:
        """UI text in SF Pro Rounded; ``size`` is unscaled."""
        self.win.string_put(x, y, color, s, self.u(size), center, "ui")

    def ui_width(self, s: str, size: int) -> int:
        """Width of UI text in pixels."""
        return self.win.text_width(s, self.u(size), "ui")

    def card(self, x: int, y: int, w: int, h: int) -> None:
        """Translucent rounded panel with a hairline border."""
        self.win.put_image(sprites.panel(w, h, self.u(20), GLASS, GLASS_EDGE,
                                         max(1, self.u(1))), x, y)

    def key_cap(self, x: int, y: int, label: str) -> int:
        """Keyboard key; returns its width."""
        h, w = self.u(34), self.key_cap_width(label)
        self.win.put_image(sprites.panel(w, h, self.u(8), (12, 12, 26, 255)),
                           x, y + self.u(3))
        self.win.put_image(sprites.panel(w, h, self.u(8), (62, 66, 100, 255),
                                         (255, 255, 255, 40),
                                         max(1, self.u(1))), x, y)
        self.ui(x + w // 2, y + (h - self.u(17)) // 2 - self.u(2), LABEL,
                label, 17)
        return w

    def pills(self, items: tuple[str, ...], y: int, size: int = 28) -> None:
        """Vertical menu; the selection is an animated yellow pill."""
        step, ph = self.u(64), self.u(52)
        pw = max(self.ui_width(s, size) for s in items) + self.u(96)
        target = float(y + self.cursor * step)
        self.pill = target if self.pill < 0 else \
            self.pill + (target - self.pill) * min(1.0, self.dt * 18)
        self.win.put_image(sprites.panel(pw, ph, ph // 2, YELLOW + (255,)),
                           (self.w - pw) // 2, round(self.pill))
        for i, item in enumerate(items):
            iy = y + i * step + (ph - self.u(size)) // 2 - self.u(3)
            on = i == self.cursor
            self.ui(self.w // 2, iy, sprites.BG if on else LABEL, item,
                    size)

    def hints(self, keys: tuple[tuple[str, str], ...]) -> None:
        """Bottom bar of keycaps with captions, centred."""
        y = self.h - self.u(64)
        gap = self.u(32)
        parts = [(key, cap, self.key_cap_width(key),
                  self.ui_width(cap, 16)) for key, cap in keys]
        total = sum(kw + self.u(10) + cw for _, _, kw, cw in parts) \
            + gap * (len(parts) - 1)
        x = (self.w - total) // 2
        for key, cap, kw, cw in parts:
            self.key_cap(x, y, key)
            self.ui(x + kw + self.u(10), y + self.u(8), LABEL2, cap, 16,
                    center=False)
            x += kw + self.u(10) + cw + gap

    def key_cap_width(self, label: str) -> int:
        """Width key_cap() will use for ``label``."""
        return max(self.u(34), self.ui_width(label, 17) + self.u(20))

    # ---- screens -----------------------------------------------------

    def draw(self) -> None:
        """Draw the current screen, then the fade veil."""
        self.win.clear(sprites.BG)
        if self.state == "menu":
            self._draw_menu()
        elif self.state == "scores":
            self._draw_scores()
        elif self.state == "help":
            self._draw_help()
        elif self.state == "message":
            self._draw_message()
        elif self.game is not None:
            self._draw_game(self.game)
            if self.state == "pause":
                self.win.put_image(self.dim, 0, 0)
                cw, ch = self.u(440), self.u(300)
                cy = (self.h - ch) // 2
                self.card((self.w - cw) // 2, cy, cw, ch)
                self.text(self.w // 2, cy + self.u(40), YELLOW, "PAUSED", 32)
                self.pills(PAUSE_MENU, cy + self.u(128))
            elif self.state == "name":
                self.win.put_image(self.dim, 0, 0)
                self._draw_name(self.game)
        if self.fade > 0:
            self.veil.rect(0, 0, self.w, self.h,
                           (sprites.BG + (round(255 * self.fade ** 2),)))
            self.win.put_image(self.veil, 0, 0)

    def _draw_menu(self) -> None:
        """Title, menu, top scores and the chase animation."""
        mid = self.w // 2
        self.text(mid, self.u(56), YELLOW, "PAC-MAN", 80)
        self.ui(mid, self.u(56) + self.fs(80) + self.u(20), PINK,
                "Ghosts! More ghosts!", 24)
        self.pills(self.menu_items(), self.u(236))
        cw, ch = self.u(420), self.u(168)
        cx, cy = (self.w - cw) // 2, self.u(568)
        self.card(cx, cy, cw, ch)
        self.ui(mid, cy + self.u(18), LABEL2, "TOP SCORES", 16)
        top = self.scores.entries[:3]
        if not top:
            self.ui(mid, cy + self.u(80), LABEL3, "No scores yet", 20)
        for i, (name, score) in enumerate(top):
            ry = cy + self.u(56) + i * self.u(36)
            self._medal(cx + self.u(28), ry, i)
            self.ui(cx + self.u(72), ry, LABEL, name, 22, center=False)
            sw = self.win.text_width(str(score), self.fs(16))
            self.win.string_put(cx + cw - self.u(28) - sw, ry + self.u(6),
                                YELLOW, str(score), self.fs(16))
        self._draw_attract(self.u(752))
        self.hints((("↑↓", "Select"), ("←→", "Mode"),
                    ("return", "Confirm")))

    def _medal(self, x: int, y: int, rank: int) -> None:
        """Round rank badge (gold, silver, bronze, then grey)."""
        d = self.u(28)
        color = MEDALS[rank] if rank < 3 else LABEL3
        self.win.put_image(sprites.panel(d, d, d // 2, color + (255,)), x, y)
        self.ui(x + d // 2, y + self.u(4), sprites.BG, str(rank + 1), 17)

    def _draw_attract(self, y: int) -> None:
        """Pac-Man chased by the ghosts, then chasing them back."""
        s = self.fs(40)
        period = 10.0
        t = self.clock % period
        span = self.w + 8 * s
        frame = int(self.clock * 6) % 2
        mouth = (0, 2, 4, 2)[int(self.clock * 12) % 4]
        if t < period / 2:
            x = -2 * s + int(t / (period / 2) * span)
            self.win.put_image(sprites.pacman(s, RIGHT, mouth), x, y)
            for i, color in enumerate(sprites.GHOST_COLORS):
                self.win.put_image(sprites.ghost(s, color, RIGHT, "normal",
                                                 frame),
                                   x - int((i + 1.6) * s * 1.15), y)
        else:
            x = self.w + 2 * s - int((t - period / 2) / (period / 2) * span)
            for i in range(4):
                self.win.put_image(sprites.ghost(s, sprites.SCARED, LEFT,
                                                 "scared", frame),
                                   x - int((i + 1.6) * s * 1.15) + 8 * s, y)
            self.win.put_image(sprites.pacman(s, LEFT, mouth), x + 9 * s, y)

    def _draw_scores(self) -> None:
        """Top-10 table in a card."""
        mid = self.w // 2
        self.text(mid, self.u(56), YELLOW, "HIGHSCORES", 48)
        cw, row = self.u(560), self.u(56)
        ch = self.u(48) + row * max(1, len(self.scores.entries))
        cx, cy = (self.w - cw) // 2, self.u(150)
        self.card(cx, cy, cw, ch)
        if not self.scores.entries:
            self.ui(mid, cy + self.u(36), LABEL3, "No scores yet", 22)
        for i, (name, score) in enumerate(self.scores.entries):
            ry = cy + self.u(24) + i * row
            if i % 2:
                self.win.put_image(sprites.panel(cw - self.u(24), row,
                                                 self.u(10),
                                                 (255, 255, 255, 10)),
                                   cx + self.u(12), ry)
            self._medal(cx + self.u(32), ry + self.u(14), i)
            self.ui(cx + self.u(84), ry + self.u(14), LABEL, name, 24,
                    center=False)
            sw = self.win.text_width(str(score), self.fs(24))
            self.win.string_put(cx + cw - self.u(36) - sw, ry + self.u(18),
                                YELLOW if i == 0 else LABEL, str(score),
                                self.fs(24))
        self.hints((("return", "Back"),))

    def _draw_help(self) -> None:
        """How to play (sprite legend) and controls (keycaps)."""
        mid = self.w // 2
        self.text(mid, self.u(48), YELLOW, "INSTRUCTIONS", 40)
        gap, cw, ch = self.u(32), self.u(520), self.u(620)
        lx, cy = mid - cw - gap // 2, self.u(130)
        rx = mid + gap // 2
        self.card(lx, cy, cw, ch)
        self.card(rx, cy, cw, ch)
        self.ui(lx + cw // 2, cy + self.u(24), LABEL2, "HOW TO PLAY", 16)
        self.ui(rx + cw // 2, cy + self.u(24), LABEL2, "CONTROLS", 16)

        s = self.u(44)
        legend: tuple[tuple[Image, str, str], ...] = (
            (sprites.dot(s), "Pac-dot",
             f"{self.cfg.points_per_pacgum} points"),
            (sprites.power(s, 1), "Power pellet",
             f"{self.cfg.points_per_super_pacgum} points, ghosts turn blue"),
            (sprites.ghost(s, sprites.SCARED, LEFT, "scared", 0),
             "Blue ghost", f"{self.cfg.points_per_ghost} points"),
            (sprites.fruit(s, "cherry"), "Bonus fruit",
             "100 to 5000 points, at 70 and 170 dots"),
        )
        y = cy + self.u(72)
        for img, title, sub in legend:
            self.win.put_image(img, lx + self.u(32), y)
            self.ui(lx + self.u(96), y, LABEL, title, 22, center=False)
            self.ui(lx + self.u(96), y + self.u(26), LABEL2, sub, 16,
                    center=False)
            y += self.u(72)
        regrow = self.cfg.food_respawn_time
        rules = (
            f"Eat every dot once to clear a level "
            f"({len(self.cfg.levels)} levels).",
            f"Each level lasts {self.cfg.level_max_time} s "
            "(twice that in Double).",
            "A ghost or the clock costs a life.",
            f"Eaten food grows back after {regrow:g} s." if regrow else
            "Eaten food never grows back.",
            f"Extra life at {self.cfg.extra_life_score} points."
            if self.cfg.extra_life_score else "No extra life.",
        )
        for line in rules:
            self.ui(lx + self.u(32), y + self.u(8), LABEL2, line, 16,
                    center=False)
            y += self.u(30)

        y = cy + self.u(64)
        rows: tuple[tuple[tuple[str, ...], str], ...] = (
            (("↑", "↓", "←", "→"), "Move"),
            (("W", "A", "S", "D"), "Move"),
            (("P", "esc"), "Pause"),
            (("C",), "Cheat mode on / off"),
        ) + tuple(((k,), what) for k, what in CHEATS)
        for keys, what in rows:
            x = rx + self.u(32)
            for k in keys:
                x += self.key_cap(x, y, k) + self.u(8)
            self.ui(rx + self.u(232), y + self.u(6), LABEL, what, 20,
                    center=False)
            y += self.u(48)
        self.hints((("return", "Back"),))

    def _draw_message(self) -> None:
        """Maze generator error."""
        cw, ch = self.u(760), self.u(320)
        cx, cy = (self.w - cw) // 2, (self.h - ch) // 2
        self.card(cx, cy, cw, ch)
        self.text(self.w // 2, cy + self.u(36), RED, "MAZE ERROR", 32)
        line, y = "", cy + self.u(110)
        for word in self.message.split() + [""]:
            if word and self.ui_width(f"{line} {word}", 20) < cw - self.u(80):
                line = f"{line} {word}".strip()
                continue
            self.ui(self.w // 2, y, LABEL, line, 20)
            line, y = word, y + self.u(30)
        self.hints((("return", "Back"),))

    def _draw_name(self, g: Game) -> None:
        """Game over / victory card with the name field."""
        mid = self.w // 2
        cw, ch = self.u(620), self.u(480)
        cx, cy = (self.w - cw) // 2, (self.h - ch) // 2
        self.card(cx, cy, cw, ch)
        if g.state == "won":
            self.text(mid, cy + self.u(40), YELLOW, "YOU WIN!", 48)
            self.ui(mid, cy + self.u(112), PINK, "Every level cleared", 22)
        else:
            self.text(mid, cy + self.u(48), RED, "GAME OVER", 48)
        self.ui(mid, cy + self.u(160), LABEL2, "FINAL SCORE", 16)
        self.text(mid, cy + self.u(188), LABEL, str(g.score), 40)
        fw, fh = self.u(420), self.u(64)
        fx, fy = (self.w - fw) // 2, cy + self.u(272)
        self.win.put_image(sprites.panel(fw, fh, self.u(14),
                                         (8, 8, 20, 255), YELLOW + (255,),
                                         max(2, self.u(2))), fx, fy)
        ty = fy + (fh - self.fs(24)) // 2
        self.text(mid, ty, LABEL, self.name, 24)
        if int(self.clock * 2) % 2:
            half = self.win.text_width(self.name, self.fs(24)) // 2
            self.text(mid + half, ty, YELLOW, "_", 24, center=False)
        self.ui(mid, fy + fh + self.u(12), LABEL3,
                "Letters, digits and spaces, 10 max", 15)
        hy = cy + ch - self.u(64)
        x = mid - self.u(150)
        x += self.key_cap(x, hy, "return") + self.u(10)
        self.ui(x, hy + self.u(8), LABEL2, "Save", 16, center=False)
        x = mid + self.u(40)
        x += self.key_cap(x, hy, "esc") + self.u(10)
        self.ui(x, hy + self.u(8), LABEL2, "Skip", 16, center=False)

    # ---- game --------------------------------------------------------

    def _maze_image(self, lv: Level, size: int, flash: bool) -> Image:
        """Cached rendering of the current level's walls."""
        key = (size, flash)
        if key not in self._mazes:
            self._mazes[key] = sprites.maze(lv, size, flash)
        return self._mazes[key]

    def _new_level(self, g: Game, size: int) -> None:
        """Reset caches and queue every sprite this level will need."""
        self._maze_level, self._mazes = g.level, {}
        lv, s = g.level, size
        jobs: list[Callable[[], object]] = [
            partial(self._maze_image, lv, s, True),
            partial(sprites.fruit, s, g.fruit_kind()[0])]
        jobs += [partial(sprites.pacman, s, UP, m)
                 for m in range(sprites.MOUTH_STEPS + 1)]
        for d in (UP, DOWN, LEFT, RIGHT, (0, 0)):
            jobs += [partial(sprites.pacman, s, d, m) for m in (0, 2, 4)]
            jobs.append(partial(sprites.ghost, s, sprites.WHITE, d, "eyes",
                                0))
            jobs += [partial(sprites.ghost, s, c, d, "normal", f)
                     for c in sprites.GHOST_COLORS for f in (0, 1)]
        jobs += [partial(sprites.ghost, s, sprites.SCARED, (0, 0), m, f)
                 for m in ("scared", "flash") for f in (0, 1)]
        self._warm = jobs[::-1]

    def _draw_game(self, g: Game) -> None:
        """Draw HUD, maze, pellets, fruit, ghosts, Pac-Man and banners."""
        lv = g.level
        hud, foot = self.u(88), self.u(64)
        size = max(8, min((self.w - self.u(48)) // lv.cols,
                          (self.h - hud - foot) // lv.rows))
        if self._maze_level is not lv:
            self._new_level(g, size)
        ox = (self.w - lv.cols * size) // 2
        oy = hud + (self.h - hud - foot - lv.rows * size) // 2
        flash = g.clearing > 0 and int(g.clearing * 5) % 2 == 0
        self.win.put_image(self._maze_image(lv, size, flash), ox, oy)

        phase = int(self.clock * 6) % 4
        for (x, y), big in lv.pellets.items():
            img = sprites.power(size, phase) if big else sprites.dot(size)
            self.win.put_image(img, ox + x * size, oy + y * size)
        if g.fruit > 2 or (g.fruit > 0 and int(self.clock * 6) % 2):
            sx, sy = lv.start
            self.win.put_image(sprites.fruit(size, g.fruit_kind()[0]),
                               ox + sx * size, oy + sy * size)

        dying = g.dying / DEATH_TIME if g.dying > 0 else 1.0
        if dying > 0.75 and g.clearing <= 0:
            frame = int(self.clock * 6) % 2
            for gh in g.ghosts:
                gx, gy = gh.pos()
                self.win.put_image(self._ghost_image(size, gh, frame),
                                   ox + round(gx * size),
                                   oy + round(gy * size))
        self._draw_player(g, size, ox, oy, dying)
        for fx, fy, label, t in g.popups:
            self.text(ox + round((fx + 0.5) * size), oy + round(fy * size)
                      - int((1 - t) * size), TEAL, label, 12)
        self._draw_banners(g, size, ox, oy)
        self._draw_hud(g, foot)

    def _ghost_image(self, size: int, gh: Ghost, frame: int) -> Image:
        """Pick the right ghost sprite for its state."""
        if gh.eaten:
            return sprites.ghost(size, sprites.WHITE, gh.dir, "eyes", 0)
        if gh.frightened > 0:
            ending = gh.frightened < 2 and int(self.clock * 5) % 2 == 0
            return sprites.ghost(size, sprites.SCARED, (0, 0),
                                 "flash" if ending else "scared", frame)
        return sprites.ghost(size, sprites.GHOST_COLORS[gh.kind], gh.dir,
                             "normal", frame)

    def _draw_player(self, g: Game, size: int, ox: int, oy: int,
                     dying: float) -> None:
        """Pac-Man: chomping, closed while READY, deflating when dying."""
        p = g.player
        if dying < 0.75:
            mouth = min(sprites.MOUTH_STEPS,
                        4 + int((0.75 - dying) / 0.75 * 13))
            img = sprites.pacman(size, UP, mouth)
        elif g.ready > 0:
            img = sprites.pacman(size, p.dir, 0)
        else:
            mouth = (0, 2, 4, 2)[int(self.clock * 14) % 4] if p.nxt else 2
            img = sprites.pacman(size, p.dir, mouth)
        px, py = p.pos()
        self.win.put_image(img, ox + round(px * size), oy + round(py * size))

    def _draw_banners(self, g: Game, size: int, ox: int, oy: int) -> None:
        """READY!, LEVEL n, TIME UP! and LEVEL CLEAR! texts."""
        mid = ox + g.level.cols * size // 2
        ty = oy + g.level.start[1] * size
        below = ty + size + self.u(8)
        if g.ready > 0:
            self.text(mid, ty - self.fs(24) - self.u(8), TEAL,
                      f"LEVEL {g.level_index + 1}", 24)
            self.text(mid, below, YELLOW, "READY!", 24)
        elif g.dying > 0 and g.time_left <= 0:
            self.text(mid, below, RED, "TIME UP!", 24)
        elif g.clearing > 0:
            self.text(mid, below, YELLOW, "LEVEL CLEAR!", 24)

    def _chip(self, x: int, y: int, label: str, color: RGB) -> None:
        """Small tinted pill with a label."""
        h = self.u(28)
        w = self.ui_width(label, 15) + self.u(24)
        self.win.put_image(sprites.panel(w, h, h // 2, color + (60,)), x, y)
        self.ui(x + w // 2, y + self.u(5), color, label, 15)

    def _draw_hud(self, g: Game, foot: int) -> None:
        """Score, high score, level and time; lives, dots and chips."""
        m = self.u(32)
        cap_y, val_y = self.u(16), self.u(42)
        self.ui(m, cap_y, LABEL2, "SCORE", 15, center=False)
        self.text(m, val_y, LABEL, str(g.score), 24, center=False)
        best = max([g.score] + [s for _, s in self.scores.entries])
        self.ui(self.w // 2, cap_y, LABEL2, "HIGH SCORE", 15)
        self.text(self.w // 2, val_y, LABEL, str(best), 24)

        bar_w, bar_h = self.u(260), self.u(14)
        bx = self.w - m - bar_w
        self.ui(bx, cap_y, LABEL2,
                f"LEVEL {g.level_index + 1} / {len(self.cfg.levels)}", 15,
                center=False)
        ratio = max(0.0, min(1.0, g.time_left / g.max_time()))
        color = GREEN if ratio >= 0.5 else YELLOW if ratio >= 0.25 else RED
        by = val_y + self.u(6)
        self.win.put_image(sprites.panel(bar_w, bar_h, bar_h // 2,
                                         (255, 255, 255, 30)), bx, by)
        fill = max(bar_h, int(bar_w * ratio))
        self.win.put_image(sprites.panel(fill, bar_h, bar_h // 2,
                                         color + (255,)), bx, by)
        secs = f"{max(0, int(g.time_left + 0.99))} s"
        self.ui(bx - self.u(12) - self.ui_width(secs, 17),
                by - self.u(3), LABEL, secs, 17, center=False)

        icon = self.u(30)
        fy = self.h - foot + (foot - icon) // 2
        for i in range(min(g.lives, 12)):
            self.win.put_image(sprites.pacman(icon, LEFT, 2),
                               m + i * int(icon * 1.3), fy)
        left = f"{len(g.level.uneaten)} dots left"
        self.ui(self.w // 2, fy + self.u(4), LABEL2, left, 17)
        self.win.put_image(sprites.fruit(icon, g.fruit_kind()[0]),
                           self.w // 2 + self.ui_width(left, 17) // 2
                           + self.u(16), fy)
        chips: list[tuple[str, RGB]] = []
        if g.double:
            chips.append(("Double", TEAL))
        if g.cheat:
            chips.append(("Cheats 1-7", RED))
            chips += [(n, RED) for n, on in (
                ("Invincible", g.invincible), ("Frozen", g.frozen),
                ("Fast", g.fast)) if on]
        x = self.w - m
        for label, col in reversed(chips):
            x -= self.ui_width(label, 15) + self.u(24)
            self._chip(x, fy + self.u(1), label, col)
            x -= self.u(8)
