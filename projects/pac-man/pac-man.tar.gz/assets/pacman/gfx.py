"""Thin MiniLibX-like layer over pygame-ce.

Every pygame call of the project lives in this file, and each one has a
MiniLibX equivalent (named in the docstrings): windows, image buffers we
write pixels into, image blits, string_put and key hooks. Shapes are
built pixel by pixel in sprites.py, as one would with mlx_pixel_put.
"""

import os
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame  # noqa: E402

Color = tuple[int, int, int] | tuple[int, int, int, int]
KeyEvent = tuple[str, str]
QUIT = "quit"
FONT = Path(__file__).parent / "assets" / "PressStart2P.ttf"
UI_FONT = Path("/System/Library/Fonts/SFNSRounded.ttf")


def screen_size() -> tuple[int, int]:
    """Return the desktop size (mlx_get_screen_size)."""
    pygame.display.init()
    sizes = pygame.display.get_desktop_sizes()
    return sizes[0] if sizes else (1280, 900)


class Image:
    """Off-screen pixel buffer with alpha (mlx_new_image)."""

    def __init__(self, width: int, height: int) -> None:
        """Allocate a transparent ``width`` x ``height`` image."""
        self.width = width
        self.height = height
        self.surface = pygame.Surface((width, height), pygame.SRCALPHA)

    def pixel_put(self, x: int, y: int, color: Color) -> None:
        """Write one pixel (write into mlx_get_data_addr's buffer)."""
        self.surface.set_at((x, y), color)

    def rect(self, x: int, y: int, w: int, h: int, color: Color) -> None:
        """Fill a rectangle of the buffer (a loop of pixel writes)."""
        self.surface.fill(color, (x, y, w, h))

    def put_image(self, img: "Image", x: int, y: int) -> None:
        """Copy another image into this one (a buffer copy)."""
        self.surface.blit(img.surface, (x, y))


class Window:
    """The game window (mlx_init + mlx_new_window).

    On Retina screens the window is created high-DPI: ``width`` and
    ``height`` are real pixels (twice the size in points), so every
    sprite is drawn at full resolution.
    """

    def __init__(self, width: int, height: int, title: str) -> None:
        """Open a ``width`` x ``height`` (points) window.

        Raises:
            pygame.error: If no display is available.
        """
        pygame.display.init()
        pygame.font.init()
        self._win = pygame.Window(title, (width, height),
                                  allow_high_dpi=True)
        self.screen = self._win.get_surface()
        self.width, self.height = self.screen.get_size()
        pygame.key.set_repeat(250, 60)
        self._fonts: dict[tuple[str, int], pygame.font.Font] = {}

    def _font(self, face: str, size: int) -> pygame.font.Font:
        """Load (once) the arcade font or the UI font at ``size``."""
        font = self._fonts.get((face, size))
        if font is None:
            path = UI_FONT if face == "ui" and UI_FONT.exists() else FONT
            font = pygame.font.Font(str(path) if path.exists() else None,
                                    size)
            self._fonts[(face, size)] = font
        return font

    def clear(self, color: Color = (0, 0, 0)) -> None:
        """Paint the whole window (mlx_clear_window)."""
        self.screen.fill(color)

    def rect(self, x: int, y: int, w: int, h: int, color: Color) -> None:
        """Fill a rectangle of the frame buffer (pixel writes)."""
        self.screen.fill(color, (x, y, w, h))

    def put_image(self, img: Image, x: int, y: int) -> None:
        """Draw an image (mlx_put_image_to_window)."""
        self.screen.blit(img.surface, (x, y))

    def text_width(self, text: str, size: int, face: str = "arcade") -> int:
        """Width in pixels of ``text`` (font metrics, for layout)."""
        return self._font(face, size).size(text)[0]

    def string_put(self, x: int, y: int, color: Color, text: str,
                   size: int = 28, center: bool = False,
                   face: str = "arcade") -> None:
        """Draw text (mlx_string_put); ``center`` centres it on ``x``.

        ``face`` is "arcade" (Press Start 2P) or "ui" (the system's
        SF Pro Rounded on macOS, arcade font elsewhere).
        """
        font = self._font(face, size)
        if center:
            x -= font.size(text)[0] // 2
        self.screen.blit(font.render(text, True, color), (x, y))

    def present(self) -> None:
        """Show the frame (mlx_do_sync)."""
        self._win.flip()

    def events(self) -> list[KeyEvent]:
        """Collect key presses and close requests (mlx_hook).

        Returns:
            ``(key_name, typed_char)`` pairs; ``(QUIT, "")`` when the
            window is closed or Cmd+Q is pressed (DestroyNotify,
            mlx_hook event 17).
        """
        out: list[KeyEvent] = []
        for e in pygame.event.get():
            if e.type in (pygame.QUIT, pygame.WINDOWCLOSE):
                out.append((QUIT, ""))
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_q and e.mod & pygame.KMOD_META:
                    out.append((QUIT, ""))
                else:
                    out.append((pygame.key.name(e.key), e.unicode))
        return out

    def destroy(self) -> None:
        """Close the window (mlx_destroy_window + mlx_destroy_display)."""
        self._win.destroy()
        pygame.quit()
