"""Adapter to the assigned A-Maze-ing package, and the playable Level.

The A-Maze-ing subject fixes one thing every group shares: each cell is
a 4-bit number of *closed* walls (bit 0 = N, 1 = E, 2 = S, 3 = W). The
API around it differs per group, so the loader inspects the factory's
signature, fills the parameters it recognises, and looks for that grid
in the result. Package and factory names come from the config.
"""

import importlib
import inspect
from collections import deque
from typing import Any, Callable

Tile = tuple[int, int]

UP: Tile = (0, -1)
DOWN: Tile = (0, 1)
LEFT: Tile = (-1, 0)
RIGHT: Tile = (1, 0)
DIRS: tuple[Tile, ...] = (UP, LEFT, DOWN, RIGHT)

NORTH, EAST, SOUTH, WEST = 1, 2, 4, 8
GRID_ATTRS = ("grid", "maze", "cells", "walls", "matrix", "data")


class MazeError(Exception):
    """Raised when the maze package is missing, fails or is unusable."""


def add(t: Tile, d: Tile) -> Tile:
    """Return tile ``t`` moved by direction ``d``."""
    return (t[0] + d[0], t[1] + d[1])


def _call(fn: Callable[..., Any], values: dict[str, Any]) -> Any:
    """Call ``fn`` filling each parameter whose name we recognise.

    Args:
        fn: Class or function from the maze package.
        values: Lower-case parameter name -> value.

    Returns:
        Whatever ``fn`` returns.

    Raises:
        MazeError: If a required parameter is unknown to us.
    """
    try:
        params = inspect.signature(fn).parameters.values()
    except (TypeError, ValueError):
        return fn()
    kwargs: dict[str, Any] = {}
    missing: list[str] = []
    for p in params:
        if p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD):
            continue
        if p.name.lower() in values:
            kwargs[p.name] = values[p.name.lower()]
        elif p.default is p.empty:
            missing.append(p.name)
    if missing:
        raise MazeError(f"{getattr(fn, '__qualname__', fn)}() needs "
                        f"unknown parameters {missing}: adapt pacman/maze.py")
    return fn(**kwargs)


def _as_grid(obj: Any, w: int, h: int) -> list[list[int]] | None:
    """Turn ``obj`` into a ``grid[y][x]`` of wall nibbles if it is one.

    Accepts lists/tuples/arrays of ints or of hex strings, a hex text,
    and the transposed ``[x][y]`` layout.

    Args:
        obj: Candidate grid.
        w: Expected width in cells.
        h: Expected height in cells.

    Returns:
        The normalised grid, or None if ``obj`` is not a w x h grid.
    """
    if hasattr(obj, "tolist"):
        obj = obj.tolist()
    if isinstance(obj, str):
        obj = [line for line in obj.splitlines() if line.strip()][:h]
    if not isinstance(obj, (list, tuple)) or not obj:
        return None
    try:
        rows = [[int(c, 16) if isinstance(c, str) else int(c) for c in row]
                for row in obj]
    except (TypeError, ValueError):
        return None
    if len(rows) == w and w != h and all(len(r) == h for r in rows):
        rows = [list(col) for col in zip(*rows)]
    if len(rows) != h or any(len(r) != w for r in rows):
        return None
    if any(not 0 <= v <= 15 for r in rows for v in r):
        return None
    return rows


def _find_grid(obj: Any, w: int, h: int) -> list[list[int]] | None:
    """Look for the grid in ``obj`` itself or in its usual attributes."""
    grid = _as_grid(obj, w, h)
    for name in GRID_ATTRS:
        if grid is not None:
            break
        grid = _as_grid(getattr(obj, name, None), w, h)
    return grid


def generate_grid(package: str, factory: str, width: int, height: int,
                  seed: int) -> list[list[int]]:
    """Generate a non-perfect maze with the external package.

    Args:
        package: Importable module name (e.g. ``mazegen``).
        factory: Class or function inside it (e.g. ``MazeGenerator``).
        width: Width in cells.
        height: Height in cells.
        seed: RNG seed.

    Returns:
        ``grid[y][x]`` of closed-wall nibbles.

    Raises:
        MazeError: On any failure, with a readable message.
    """
    try:
        module = importlib.import_module(package)
    except ImportError as e:
        raise MazeError(f"cannot import maze package '{package}': {e}. "
                        "Install it with 'make install'.") from e
    fn = getattr(module, factory, None)
    if not callable(fn):
        raise MazeError(f"'{package}' has no callable '{factory}'")
    corner = (width - 1, height - 1)
    values: dict[str, Any] = {
        "width": width, "height": height, "w": width, "h": height,
        "seed": seed, "perfect": False, "is_perfect": False,
        "entry": (0, 0), "start": (0, 0), "exit": corner, "end": corner,
    }
    try:
        result = _call(fn, values)
        grid = _find_grid(result, width, height)
        generate = getattr(result, "generate", None)
        not_carved = grid is None or all(v == 15 for r in grid for v in r)
        if not_carved and callable(generate):
            grid = (_find_grid(_call(generate, values), width, height)
                    or _find_grid(result, width, height))
    except MazeError:
        raise
    except (Exception, SystemExit) as e:
        raise MazeError(f"maze generator failed: {e!r}") from e
    if grid is None:
        raise MazeError(f"no {width}x{height} wall grid found in the output "
                        f"of {package}.{factory}: adapt pacman/maze.py")
    return grid


class Level:
    """A maze converted to a tile map with pellets and spawn points.

    Cell (x, y) becomes tile (2x+1, 2y+1); the tile between two cells is
    a corridor when the wall between them is open, so walls are one tile
    thick. Only the largest connected area is playable (the fully closed
    '42' cells end up outside it).

    Attributes:
        cols: Tile columns.
        rows: Tile rows.
        region: Playable tiles.
        start: Player spawn, the playable tile closest to the centre.
        corners: Ghost spawns / super-pacgums, one per maze corner.
        pellets: Pellets on the board, tile -> True if super-pacgum.
        uneaten: Pellet tiles never eaten yet; empty = level cleared.
    """

    def __init__(self, grid: list[list[int]]) -> None:
        """Build the level from a cell grid.

        Args:
            grid: ``grid[y][x]`` closed-wall nibbles.

        Raises:
            MazeError: If the maze has almost no corridors.
        """
        h, w = len(grid), len(grid[0])
        self.cols, self.rows = 2 * w + 1, 2 * h + 1
        self._open = [[False] * self.cols for _ in range(self.rows)]
        for y in range(h):
            for x in range(w):
                self._open[2 * y + 1][2 * x + 1] = True
                if (x + 1 < w and not grid[y][x] & EAST
                        and not grid[y][x + 1] & WEST):
                    self._open[2 * y + 1][2 * x + 2] = True
                if (y + 1 < h and not grid[y][x] & SOUTH
                        and not grid[y + 1][x] & NORTH):
                    self._open[2 * y + 2][2 * x + 1] = True
        self.region = self._largest_region()
        if len(self.region) < 9:
            raise MazeError("generated maze has no usable corridors")
        self._braid()

        self.start = self.closest(self.cols / 2, self.rows / 2)
        self.corners = [self.closest(0, 0), self.closest(self.cols, 0),
                        self.closest(0, self.rows),
                        self.closest(self.cols, self.rows)]
        self.pellets: dict[Tile, bool] = {t: False for t in self.region}
        for c in self.corners:
            self.pellets[c] = True
        self.pellets.pop(self.start, None)
        self.uneaten = set(self.pellets)

    def closest(self, tx: float, ty: float) -> Tile:
        """Return the playable tile nearest to point (tx, ty)."""
        return min(self.region,
                   key=lambda t: ((t[0] - tx) ** 2 + (t[1] - ty) ** 2, t))

    def ghost_homes(self, count: int) -> list[Tile]:
        """Spawn corners in arcade order, then edge middles (Double).

        Blinky top-right, Pinky top-left, Inky bottom-right, Clyde
        bottom-left; ghosts 5-8 start at the middle of each edge.
        """
        tl, tr, bl, br = self.corners
        homes = [tr, tl, br, bl,
                 self.closest(self.cols / 2, 0),
                 self.closest(0, self.rows / 2),
                 self.closest(self.cols, self.rows / 2),
                 self.closest(self.cols / 2, self.rows)]
        return homes[:count]

    def is_open(self, t: Tile) -> bool:
        """Tell whether a tile is a corridor (False outside the map)."""
        x, y = t
        return 0 <= x < self.cols and 0 <= y < self.rows and self._open[y][x]

    def distances(self, src: Tile) -> dict[Tile, int]:
        """BFS step counts from ``src`` to every reachable tile."""
        dist = {src: 0}
        queue = deque([src])
        while queue:
            t = queue.popleft()
            for d in DIRS:
                n = add(t, d)
                if n not in dist and self.is_open(n):
                    dist[n] = dist[t] + 1
                    queue.append(n)
        return dist

    def _braid(self) -> None:
        """Remove dead ends, like every real Pac-Man maze.

        A cell with a single exit gets one more wall opened towards a
        playable neighbour cell (another dead end if possible). The
        generator's grid is untouched: only our tile map changes, and
        deterministically, so a seed still gives the same level.
        """
        for y in range(1, self.rows, 2):
            for x in range(1, self.cols, 2):
                t = (x, y)
                exits = [d for d in DIRS if self.is_open(add(t, d))]
                if t not in self.region or len(exits) != 1:
                    continue
                options = [d for d in DIRS if d not in exits
                           and (t[0] + 2 * d[0], t[1] + 2 * d[1])
                           in self.region]
                if not options:
                    continue

                def exit_count(d: Tile) -> int:
                    far = (t[0] + 2 * d[0], t[1] + 2 * d[1])
                    return sum(self.is_open(add(far, e)) for e in DIRS)

                wall = add(t, min(options, key=exit_count))
                self._open[wall[1]][wall[0]] = True
                self.region.add(wall)

    def _largest_region(self) -> set[Tile]:
        """Return the biggest set of mutually reachable open tiles."""
        best: set[Tile] = set()
        seen: set[Tile] = set()
        for y in range(self.rows):
            for x in range(self.cols):
                if self._open[y][x] and (x, y) not in seen:
                    area = set(self.distances((x, y)))
                    seen |= area
                    if len(area) > len(best):
                        best = area
        return best
