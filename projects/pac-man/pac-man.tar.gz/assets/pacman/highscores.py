"""Persistent top-10 highscore table stored as a JSON file."""

import json
import logging
import os
import re
from pathlib import Path

log = logging.getLogger("pacman")

MAX_ENTRIES = 10
NAME_MAX = 10
_NAME_RE = re.compile(r"[A-Za-z0-9 ]{1,10}")


def valid_name(name: str) -> bool:
    """Tell whether a player name is acceptable.

    Args:
        name: Candidate name.

    Returns:
        True for 1-10 ASCII letters, digits or spaces, not all spaces.
    """
    return bool(_NAME_RE.fullmatch(name)) and bool(name.strip())


def valid_char(ch: str) -> bool:
    """Tell whether a typed character may be part of a name.

    Args:
        ch: One character.

    Returns:
        True for an ASCII letter, digit or space.
    """
    return len(ch) == 1 and ch.isascii() and (ch.isalnum() or ch == " ")


class Highscores:
    """Top-10 (name, score) list, best first.

    Attributes:
        path: JSON file holding ``[{"name": str, "score": int}, ...]``.
        entries: Current table.
    """

    def __init__(self, path: str) -> None:
        """Create an empty table bound to a file.

        Args:
            path: Where the table is loaded from and saved to.
        """
        self.path = Path(path)
        self.entries: list[tuple[str, int]] = []

    def load(self) -> None:
        """Load the file; any error leaves an empty (or partial) table."""
        self.entries = []
        if not self.path.exists():
            return
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as e:
            log.warning("highscores: cannot read '%s' (%s), starting empty",
                        self.path, e)
            return
        if not isinstance(data, list):
            log.warning("highscores: '%s' is not a list, starting empty",
                        self.path)
            return
        for item in data:
            name = item.get("name") if isinstance(item, dict) else None
            score = item.get("score") if isinstance(item, dict) else None
            if (isinstance(name, str) and valid_name(name)
                    and isinstance(score, int)
                    and not isinstance(score, bool) and score >= 0):
                self.entries.append((name, score))
            else:
                log.warning("highscores: skipping invalid entry %r", item)
        self._trim()

    def save(self) -> bool:
        """Write the table atomically (temp file + rename).

        Returns:
            True on success, False if the disk refused (logged).
        """
        tmp = self.path.with_name(self.path.name + ".tmp")
        data = [{"name": n, "score": s} for n, s in self.entries]
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self.path)
        except OSError as e:
            log.warning("highscores: cannot save '%s': %s", self.path, e)
            return False
        return True

    def add(self, name: str, score: int) -> None:
        """Insert a result, keeping only the best MAX_ENTRIES.

        Args:
            name: Player name (invalid names are rejected).
            score: Non-negative score.

        Raises:
            ValueError: On an invalid name or negative score.
        """
        if not valid_name(name) or score < 0:
            raise ValueError(f"invalid highscore entry {name!r}={score}")
        self.entries.append((name, score))
        self._trim()

    def _trim(self) -> None:
        """Sort best first (stable: older entry wins ties) and cut."""
        self.entries.sort(key=lambda e: -e[1])
        del self.entries[MAX_ENTRIES:]
