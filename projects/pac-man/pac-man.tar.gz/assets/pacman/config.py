"""Config loading: JSON with comment lines, validated and clamped."""

import json
import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

log = logging.getLogger("pacman")

MIN_LEVELS = 10
DEFAULT_LEVELS: list[tuple[int, int]] = [
    (13, 9), (14, 9), (14, 10), (15, 10), (16, 10),
    (16, 11), (17, 11), (18, 12), (19, 12), (19, 13),
]
WIDTH_RANGE = (5, 40)
HEIGHT_RANGE = (5, 30)

# key -> (min, max); the default lives on the Config dataclass.
INT_KEYS: dict[str, tuple[int, int]] = {
    "lives": (1, 99),
    "points_per_pacgum": (0, 100_000),
    "points_per_super_pacgum": (0, 100_000),
    "points_per_ghost": (0, 100_000),
    "seed": (0, 2**31 - 1),
    "level_max_time": (10, 3600),
    "extra_life_score": (0, 10_000_000),
}
FLOAT_KEYS: dict[str, tuple[float, float]] = {
    "frightened_time": (1.0, 60.0),
    "ghost_respawn_time": (1.0, 60.0),
    "player_speed": (2.0, 20.0),
    "ghost_speed": (1.0, 20.0),
    "food_respawn_time": (0.0, 600.0),
}
STR_KEYS = ("highscore_filename", "maze_package", "maze_factory")
BOOL_KEYS = ("cheat_mode", "double_mode")


class ConfigError(Exception):
    """Raised when the config file cannot be read or parsed at all."""


@dataclass
class LevelSpec:
    """Size of one level's maze, in A-Maze-ing cells."""

    width: int
    height: int


@dataclass
class Config:
    """All game parameters, with safe defaults."""

    highscore_filename: str = "highscores.json"
    lives: int = 3
    points_per_pacgum: int = 10
    points_per_super_pacgum: int = 50
    points_per_ghost: int = 200
    seed: int = 42
    level_max_time: int = 150
    frightened_time: float = 6.0
    ghost_respawn_time: float = 5.0
    player_speed: float = 8.0
    ghost_speed: float = 7.0
    food_respawn_time: float = 30.0
    extra_life_score: int = 10_000
    cheat_mode: bool = False
    double_mode: bool = False
    maze_package: str = "mazegen"
    maze_factory: str = "MazeGenerator"
    levels: list[LevelSpec] = field(
        default_factory=lambda: [LevelSpec(w, h) for w, h in DEFAULT_LEVELS]
    )


def strip_comments(text: str) -> str:
    """Blank out lines starting with '#' or '//' (keeps line numbers).

    Args:
        text: Raw file content.

    Returns:
        Plain JSON text.
    """
    return "\n".join(
        "" if line.lstrip().startswith(("#", "//")) else line
        for line in text.splitlines()
    )


def _clamp(key: str, value: Any, default: float,
           lo: float, hi: float, as_int: bool) -> Any:
    """Validate a number, clamping it into [lo, hi].

    Args:
        key: Config key, for messages.
        value: Raw value from JSON.
        default: Value used when ``value`` is not a finite number.
        lo: Minimum allowed.
        hi: Maximum allowed.
        as_int: Whether only integers are accepted.

    Returns:
        The validated (int or float) value.
    """
    allowed = (int,) if as_int else (int, float)
    if (isinstance(value, bool) or not isinstance(value, allowed)
            or (isinstance(value, float) and not math.isfinite(value))):
        log.warning("config: '%s' must be %s, using %s", key,
                    "an integer" if as_int else "a finite number", default)
        return default
    if not lo <= value <= hi:
        clamped = min(max(value, lo), hi)
        log.warning("config: '%s'=%s out of [%s, %s], clamped to %s",
                    key, value, lo, hi, clamped)
        value = clamped
    return int(value) if as_int else float(value)


def _parse_levels(raw: Any) -> list[LevelSpec]:
    """Validate the ``levels`` array, padding it to MIN_LEVELS.

    Args:
        raw: Raw value of the ``levels`` key.

    Returns:
        At least MIN_LEVELS level specs.
    """
    if not isinstance(raw, list) or not raw:
        log.warning("config: 'levels' must be a non-empty array, "
                    "using the default levels")
        raw = []
    levels: list[LevelSpec] = []
    for i, item in enumerate(raw):
        dw, dh = DEFAULT_LEVELS[i % len(DEFAULT_LEVELS)]
        if not isinstance(item, dict):
            log.warning("config: levels[%d] is not an object, using %dx%d",
                        i, dw, dh)
            item = {}
        w = _clamp(f"levels[{i}].width", item.get("width", dw), dw,
                   *WIDTH_RANGE, as_int=True)
        h = _clamp(f"levels[{i}].height", item.get("height", dh), dh,
                   *HEIGHT_RANGE, as_int=True)
        levels.append(LevelSpec(w, h))
    if raw and len(levels) < MIN_LEVELS:
        log.warning("config: %d levels given, at least %d required: "
                    "padding with default levels", len(levels), MIN_LEVELS)
    while len(levels) < MIN_LEVELS:
        levels.append(LevelSpec(*DEFAULT_LEVELS[len(levels)]))
    return levels


def load_config(path: str) -> Config:
    """Read, parse and validate a config file.

    Bad values are clamped or replaced by defaults with a warning;
    unknown keys are ignored.

    Args:
        path: Path to the JSON (with comments) config file.

    Returns:
        A fully valid Config.

    Raises:
        ConfigError: If the file is unreadable or not a JSON object.
    """
    try:
        with open(path, encoding="utf-8") as f:
            text = f.read()
    except (OSError, UnicodeDecodeError) as e:
        raise ConfigError(f"cannot read config file '{path}': {e}") from e
    try:
        data = json.loads(strip_comments(text))
    except json.JSONDecodeError as e:
        raise ConfigError(f"'{path}' is not valid JSON (line {e.lineno}, "
                          f"column {e.colno}): {e.msg}") from e
    if not isinstance(data, dict):
        raise ConfigError(f"'{path}' must contain a JSON object")

    cfg = Config()
    known = {*INT_KEYS, *FLOAT_KEYS, *STR_KEYS, *BOOL_KEYS, "levels"}
    for key in data:
        if key not in known:
            log.info("config: ignoring unknown key '%s'", key)
    for key, (lo, hi) in INT_KEYS.items():
        if key in data:
            setattr(cfg, key, _clamp(key, data[key], getattr(cfg, key),
                                     lo, hi, as_int=True))
    for key, (flo, fhi) in FLOAT_KEYS.items():
        if key in data:
            setattr(cfg, key, _clamp(key, data[key], getattr(cfg, key),
                                     flo, fhi, as_int=False))
    for key in STR_KEYS:
        value = data.get(key, getattr(cfg, key))
        if not isinstance(value, str) or not value.strip():
            log.warning("config: '%s' must be a non-empty string, using "
                        "'%s'", key, getattr(cfg, key))
        else:
            setattr(cfg, key, value.strip())
    for key in BOOL_KEYS:
        value = data.get(key, getattr(cfg, key))
        if not isinstance(value, bool):
            log.warning("config: '%s' must be true or false", key)
        else:
            setattr(cfg, key, value)
    if "levels" in data:
        cfg.levels = _parse_levels(data["levels"])

    # Relative highscore paths live next to the config file.
    hs = Path(cfg.highscore_filename)
    if not hs.is_absolute():
        cfg.highscore_filename = str(Path(path).resolve().parent / hs)
    return cfg
