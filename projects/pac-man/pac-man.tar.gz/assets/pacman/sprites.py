"""Sprites drawn pixel by pixel into images, cached per tile size.

Every shape is a signed distance function (negative inside): the pixel
coverage ``clamp(0.5 - sdf)`` gives smooth, anti-aliased edges with a
single pixel_put per pixel.
"""

import math
from functools import lru_cache
from typing import Callable

from pacman.gfx import Color, Image
from pacman.maze import DIRS, Level, Tile, add

RGB = tuple[int, int, int]

BG: RGB = (4, 4, 16)
WALL_EDGE: RGB = (64, 96, 255)
WALL_FILL: RGB = (10, 12, 48)
FLASH_EDGE: RGB = (240, 240, 255)
FLASH_FILL: RGB = (70, 70, 110)
BLOCK_EDGE: RGB = (255, 70, 210)
BLOCK_FILL: RGB = (60, 6, 70)
YELLOW: RGB = (255, 226, 0)
PELLET: RGB = (255, 196, 160)
WHITE: RGB = (255, 255, 255)
PUPIL: RGB = (30, 40, 200)
SCARED: RGB = (40, 50, 235)
SCARED_FLASH: RGB = (235, 235, 255)
SCARED_FACE: RGB = (255, 200, 170)
GHOST_COLORS: tuple[RGB, ...] = (
    (255, 30, 30), (255, 150, 220), (0, 230, 255), (255, 170, 60))
MOUTH_STEPS = 16          # mouth half-angle = step * pi / MOUTH_STEPS


def _cov(sdf: float) -> float:
    """Pixel coverage of a shape from its signed distance."""
    return min(1.0, max(0.0, 0.5 - sdf))


def _mix(a: RGB, b: RGB, t: float) -> RGB:
    """Blend colour ``a`` towards ``b`` by ``t``."""
    return (round(a[0] + (b[0] - a[0]) * t),
            round(a[1] + (b[1] - a[1]) * t),
            round(a[2] + (b[2] - a[2]) * t))


def _shade(c: RGB, k: float) -> RGB:
    """Scale a colour's brightness by ``k``."""
    return (min(255, round(c[0] * k)), min(255, round(c[1] * k)),
            min(255, round(c[2] * k)))


def _put(img: Image, x: int, y: int, c: RGB, alpha: float) -> None:
    """pixel_put with an alpha in [0, 1] (skips empty pixels)."""
    if alpha > 0.003:
        rgba: Color = (c[0], c[1], c[2], round(min(1.0, alpha) * 255))
        img.pixel_put(x, y, rgba)


def _segment(px: float, py: float, ax: float, ay: float,
             bx: float, by: float) -> float:
    """Distance from point p to segment ab."""
    vx, vy = bx - ax, by - ay
    length = vx * vx + vy * vy
    t = 0.0 if length == 0 else max(0.0, min(1.0, ((px - ax) * vx
                                                   + (py - ay) * vy) / length))
    return math.hypot(px - ax - t * vx, py - ay - t * vy)


@lru_cache(maxsize=None)
def dot(size: int) -> Image:
    """Small pacgum with a faint halo."""
    img = Image(size, size)
    c, r = size / 2, max(1.5, size * 0.09)
    for y in range(size):
        for x in range(size):
            d = math.hypot(x + 0.5 - c, y + 0.5 - c)
            halo = 0.25 * max(0.0, 1 - (d - r) / r) ** 2
            _put(img, x, y, PELLET, max(_cov(d - r), halo))
    return img


@lru_cache(maxsize=None)
def power(size: int, phase: int) -> Image:
    """Super-pacgum, pulsing over 4 phases, with a glow."""
    img = Image(size, size)
    c = size / 2
    r = size * (0.2 + 0.035 * math.sin(phase * math.pi / 2))
    for y in range(size):
        for x in range(size):
            d = math.hypot(x + 0.5 - c, y + 0.5 - c)
            glow = 0.45 * max(0.0, 1 - (d - r) / (c - r)) ** 2
            _put(img, x, y, _mix(PELLET, WHITE, _cov(d - r * 0.5) * 0.5),
                 max(_cov(d - r), glow))
    return img


@lru_cache(maxsize=None)
def pacman(size: int, d: Tile, mouth: int) -> Image:
    """Pac-Man facing ``d``, mouth half-angle ``mouth`` * pi/16.

    Args:
        size: Tile size in pixels.
        d: Facing direction ((0, 0) = right).
        mouth: 0 (closed) to MOUTH_STEPS (gone: end of death).
    """
    img = Image(size, size)
    c, r = size / 2, size * 0.47
    face = math.atan2(d[1], d[0]) if d != (0, 0) else 0.0
    half = mouth * math.pi / MOUTH_STEPS
    for y in range(size):
        for x in range(size):
            dx, dy = x + 0.5 - c, y + 0.5 - c
            dist = math.hypot(dx, dy)
            a = abs((math.atan2(dy, dx) - face + math.pi) % math.tau
                    - math.pi)
            # signed distance into the mouth wedge (> 0 inside it)
            wedge = dist * math.sin(max(-math.pi / 2,
                                        min(math.pi / 2, half - a)))
            cov = min(_cov(dist - r), _cov(wedge)) if mouth else \
                _cov(dist - r)
            light = 1.12 - 0.3 * max(0.0, (dx * 0.5 + dy * 0.8) / r)
            _put(img, x, y, _shade(YELLOW, light), cov)
    return img


def _eye(dx: float, dy: float, rx: float, ry: float) -> float:
    """Approximate signed distance to an axis-aligned ellipse."""
    return (math.hypot(dx / rx, dy / ry) - 1) * min(rx, ry)


@lru_cache(maxsize=None)
def ghost(size: int, color: RGB, d: Tile, mode: str, frame: int) -> Image:
    """Ghost with a wavy skirt.

    Args:
        size: Tile size in pixels.
        color: Body colour (ignored when scared).
        d: Where the eyes look.
        mode: "normal", "scared", "flash" (scared, ending) or "eyes".
        frame: Skirt animation frame, 0 or 1.
    """
    img = Image(size, size)
    c, r = size / 2, size * 0.45
    hy = c - size * 0.05
    bottom = c + r * 0.98
    amp = r * 0.2
    if mode in ("scared", "flash"):
        color = SCARED if mode == "scared" else SCARED_FLASH
    face = (255, 60, 60) if mode == "flash" else SCARED_FACE
    for y in range(size):
        for x in range(size):
            px, py = x + 0.5, y + 0.5
            dx = px - c
            skirt = bottom - amp * (0.5 + 0.5 * math.cos(
                dx / r * math.pi * 2.5 + frame * math.pi))
            body = max(abs(dx) - r, py - skirt, hy - py)
            sdf = min(math.hypot(dx, py - hy) - r, body)
            light = 1.15 - 0.4 * (py - (hy - r)) / (2 * r)
            col = _shade(color, light)
            if sdf > -1.6:
                col = _shade(col, 0.7)
            alpha = 0.0 if mode == "eyes" else _cov(sdf)
            if mode in ("scared", "flash"):
                for side in (-1, 1):
                    e = math.hypot(dx - side * r * 0.36, py - hy) - r * 0.13
                    col = _mix(col, face, _cov(e))
                wave = hy + r * 0.5 + r * 0.12 * math.cos(dx / r * math.pi * 4)
                if abs(dx) < r * 0.62:
                    col = _mix(col, face, _cov(abs(py - wave) - size / 40))
            else:
                for side in (-1, 1):
                    ex, ey = c + side * r * 0.38, hy - r * 0.05
                    white = _cov(_eye(px - ex, py - ey, r * 0.27, r * 0.34))
                    pupil = _cov(math.hypot(px - ex - d[0] * r * 0.13,
                                            py - ey - d[1] * r * 0.15)
                                 - r * 0.15)
                    col = _mix(_mix(col, WHITE, white), PUPIL, pupil)
                    alpha = max(alpha, white)
            _put(img, x, y, col, alpha)
    return img


@lru_cache(maxsize=None)
def _wall_tile(size: int, mask: int, flash: bool) -> Image:
    """Neon tube for one wall tile; ``mask`` bit i = joined to DIRS[i]."""
    img = Image(size, size)
    c = size / 2
    half = size * 0.2
    edge_w = max(1.5, size * 0.07)
    glow_w = size * 0.3
    edge, fill = (FLASH_EDGE, FLASH_FILL) if flash else (WALL_EDGE, WALL_FILL)
    if mask == 0:                     # lone pillar: solid, not a ring
        fill = edge
    ends = [(c + d[0] * c, c + d[1] * c)
            for i, d in enumerate(DIRS) if mask >> i & 1] or [(c, c)]
    for y in range(size):
        for x in range(size):
            px, py = x + 0.5, y + 0.5
            sdf = min(_segment(px, py, c, c, ex, ey) for ex, ey in ends) - half
            inside = _cov(sdf)
            band = _cov(abs(sdf + edge_w / 2) - edge_w / 2)
            glow = 0.4 * max(0.0, 1 - sdf / glow_w) ** 2 if sdf > 0 else 0.0
            if inside > 0:
                _put(img, x, y, _mix(fill, edge, band), max(inside, glow))
            else:
                _put(img, x, y, edge, glow)
    return img


@lru_cache(maxsize=None)
def _block_tile(size: int) -> Image:
    """Glowing block for the unreachable '42' cells."""
    img = Image(size, size)
    c, half, rad = size / 2, size * 0.36, size * 0.12
    edge_w = max(1.5, size * 0.07)
    for y in range(size):
        for x in range(size):
            qx = abs(x + 0.5 - c) - half + rad
            qy = abs(y + 0.5 - c) - half + rad
            sdf = (math.hypot(max(qx, 0.0), max(qy, 0.0))
                   + min(max(qx, qy), 0.0) - rad)
            band = _cov(abs(sdf + edge_w / 2) - edge_w / 2)
            glow = 0.45 * max(0.0, 1 - sdf / (size * 0.14)) ** 2 \
                if sdf > 0 else 0.0
            _put(img, x, y, _mix(BLOCK_FILL, BLOCK_EDGE, band),
                 max(_cov(sdf), glow))
    return img


def maze(level: Level, size: int, flash: bool = False) -> Image:
    """Render the static walls of a level once into one image."""
    img = Image(level.cols * size, level.rows * size)
    for y in range(level.rows):
        for x in range(level.cols):
            if level.is_open((x, y)):
                if (x, y) not in level.region:
                    img.put_image(_block_tile(size), x * size, y * size)
                continue
            mask = 0
            for i, d in enumerate(DIRS):
                n = add((x, y), d)
                if (0 <= n[0] < level.cols and 0 <= n[1] < level.rows
                        and not level.is_open(n)):
                    mask |= 1 << i
            img.put_image(_wall_tile(size, mask, flash), x * size, y * size)
    return img


# ---- fruit ---------------------------------------------------------------

Sdf = Callable[[float, float], float]


def _circle(cx: float, cy: float, r: float) -> Sdf:
    """Disc in unit space."""
    return lambda u, v: math.hypot(u - cx, v - cy) - r


def _ellipse(cx: float, cy: float, rx: float, ry: float) -> Sdf:
    """Ellipse in unit space."""
    return lambda u, v: _eye(u - cx, v - cy, rx, ry)


def _stick(ax: float, ay: float, bx: float, by: float, w: float) -> Sdf:
    """Rounded segment (capsule) in unit space."""
    return lambda u, v: _segment(u, v, ax, ay, bx, by) - w


def _union(*parts: Sdf) -> Sdf:
    """Union of shapes."""
    return lambda u, v: min(p(u, v) for p in parts)


def _ring(shape: Sdf, w: float) -> Sdf:
    """Outline of a shape, ``w`` thick."""
    return lambda u, v: abs(shape(u, v)) - w


GREEN: RGB = (60, 200, 70)
STEM: RGB = (150, 90, 40)
SHINE: RGB = (255, 255, 255)

FRUIT_ART: dict[str, tuple[tuple[Sdf, RGB], ...]] = {
    "cherry": (
        (_stick(0.33, 0.66, 0.66, 0.16, 0.03), STEM),
        (_stick(0.68, 0.70, 0.66, 0.16, 0.03), STEM),
        (_circle(0.31, 0.68, 0.2), (230, 20, 40)),
        (_circle(0.68, 0.72, 0.2), (230, 20, 40)),
        (_circle(0.25, 0.62, 0.05), SHINE),
        (_circle(0.62, 0.66, 0.05), SHINE)),
    "strawberry": (
        (_union(_circle(0.5, 0.45, 0.3), _ellipse(0.5, 0.62, 0.22, 0.3)),
         (240, 30, 50)),
        (_circle(0.4, 0.45, 0.025), (255, 240, 180)),
        (_circle(0.6, 0.5, 0.025), (255, 240, 180)),
        (_circle(0.48, 0.65, 0.025), (255, 240, 180)),
        (_circle(0.36, 0.6, 0.025), (255, 240, 180)),
        (_circle(0.62, 0.68, 0.025), (255, 240, 180)),
        (_ellipse(0.5, 0.2, 0.24, 0.08), GREEN)),
    "orange": (
        (_stick(0.5, 0.24, 0.52, 0.1, 0.025), STEM),
        (_circle(0.5, 0.56, 0.34), (255, 150, 20)),
        (_ellipse(0.64, 0.17, 0.13, 0.06), GREEN),
        (_circle(0.38, 0.45, 0.06), (255, 210, 140))),
    "apple": (
        (_stick(0.5, 0.3, 0.54, 0.1, 0.025), STEM),
        (_union(_circle(0.38, 0.58, 0.27), _circle(0.62, 0.58, 0.27)),
         (220, 25, 40)),
        (_ellipse(0.66, 0.18, 0.12, 0.05), GREEN),
        (_circle(0.32, 0.5, 0.06), SHINE)),
    "melon": (
        (_ellipse(0.5, 0.56, 0.34, 0.36), (90, 200, 80)),
        (_ring(_ellipse(0.5, 0.56, 0.12, 0.36), 0.015), (30, 110, 40)),
        (_ring(_ellipse(0.5, 0.56, 0.25, 0.36), 0.015), (30, 110, 40)),
        (_stick(0.5, 0.2, 0.5, 0.1, 0.025), STEM)),
    "galaxian": (
        (_stick(0.18, 0.3, 0.5, 0.62, 0.07), (40, 90, 255)),
        (_stick(0.82, 0.3, 0.5, 0.62, 0.07), (40, 90, 255)),
        (_stick(0.5, 0.25, 0.5, 0.78, 0.09), (255, 220, 0)),
        (_circle(0.5, 0.3, 0.07), (230, 30, 30))),
    "bell": (
        (lambda u, v: min(math.hypot(u - 0.5, v - 0.42) - 0.26,
                          max(abs(u - 0.5) - 0.24 - (v - 0.42) * 0.45,
                              v - 0.78, 0.42 - v)), (255, 210, 0)),
        (_circle(0.5, 0.82, 0.07), (120, 200, 255)),
        (_ellipse(0.4, 0.4, 0.05, 0.12), SHINE)),
    "key": (
        (_ring(_circle(0.5, 0.27, 0.16), 0.05), (120, 200, 255)),
        (_stick(0.5, 0.45, 0.5, 0.86, 0.05), (210, 210, 230)),
        (_stick(0.5, 0.72, 0.64, 0.72, 0.04), (210, 210, 230)),
        (_stick(0.5, 0.83, 0.62, 0.83, 0.04), (210, 210, 230))),
}


@lru_cache(maxsize=None)
def fruit(size: int, name: str) -> Image:
    """Bonus fruit, layers of unit-space shapes painted in order."""
    img = Image(size, size)
    layers = FRUIT_ART.get(name, FRUIT_ART["cherry"])
    for y in range(size):
        for x in range(size):
            u, v = (x + 0.5) / size, (y + 0.5) / size
            col, alpha = WHITE, 0.0
            for shape, color in layers:
                c = _cov(shape(u, v) * size)
                if c > 0:
                    col = _mix(col, color, c) if alpha > 0 else color
                    alpha = alpha + c * (1 - alpha)
            _put(img, x, y, col, alpha)
    return img


# ---- UI panels (Apple-style rounded "glass") -----------------------------

RGBA = tuple[int, int, int, int]


@lru_cache(maxsize=128)
def panel(w: int, h: int, radius: int, fill: RGBA,
          border: RGBA | None = None, bw: int = 0) -> Image:
    """Rounded rectangle with optional border, anti-aliased corners.

    The straight parts are rectangle fills; only the four corners are
    computed pixel by pixel, so even full-screen panels are cheap.
    """
    img = Image(w, h)
    r = max(1, min(radius, w // 2, h // 2))
    edge = border or fill
    img.rect(r, 0, w - 2 * r, h, fill)
    img.rect(0, r, w, h - 2 * r, fill)
    if border and bw:
        img.rect(r, 0, w - 2 * r, bw, border)
        img.rect(r, h - bw, w - 2 * r, bw, border)
        img.rect(0, r, bw, h - 2 * r, border)
        img.rect(w - bw, r, bw, h - 2 * r, border)
    for cx, cy, x0, y0 in ((r, r, 0, 0), (w - r, r, w - r, 0),
                           (r, h - r, 0, h - r), (w - r, h - r, w - r, h - r)):
        for y in range(y0, y0 + r):
            for x in range(x0, x0 + r):
                sdf = math.hypot(x + 0.5 - cx, y + 0.5 - cy) - r
                inner = _cov(sdf + bw) if border and bw else 1.0
                rgb = _mix(edge[:3], fill[:3], inner)
                a = (edge[3] + (fill[3] - edge[3]) * inner) / 255
                _put(img, x, y, rgb, a * _cov(sdf))
    return img
